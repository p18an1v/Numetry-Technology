
package com.springBill.Controller;

import com.springBill.model.Bill;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class BillController {

    @GetMapping("/index")
    public String viewForm(Model model) {
        System.out.println("index is accesd");
        model.addAttribute("bill", new Bill());
        return "index";
    }


    @PostMapping("/bill")
    public String addForm(@ModelAttribute Bill bill, Model model) {
        System.out.println("Bill is generated");
        model.addAttribute("bill", bill);
        return "calculate";
    }
}
