package com.springBill.model;

import org.springframework.stereotype.Component;

// Model
@Component
	public class Bill {

		private String name;
		private int units;
		private double rate;

		public Bill() {
			super();
			this.name = name;
			this.units = units;
			this.rate = rate;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getUnits() {
			return units;
		}

		public void setUnits(int units) {
			this.units = units;
		}

		public double getRate() {
			return rate;
		}

		public void setRate(double rate) {
			this.rate = rate;
		}

		public double Total() {
			return units * rate;
		}
	}


