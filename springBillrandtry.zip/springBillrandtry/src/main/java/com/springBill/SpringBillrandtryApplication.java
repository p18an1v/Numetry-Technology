package com.springBill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.springBill.controller", "com.springBill.model"})
public class SpringBillrandtryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBillrandtryApplication.class, args);
		System.out.println("applcation started");
	}

}
